package com.example.todelrecyclerviewjsonvolley;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    /** Vars globales **/
    private RecyclerView recyclerView;
    private AdapterItem adapterItem;
    private ArrayList<ModelItem> itemArrayList;
    private RequestQueue requestQueue;
    private String search;

    private EditText etSearch;


    /** Initialisation des composants **/
    public void init(){
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        etSearch = findViewById(R.id.etSearch);

        itemArrayList = new ArrayList<>();

        requestQueue = Volley.newRequestQueue(this);
    }

    /** Méthode pour parse le Json **/
    private void parseJSON(String search){
        String urlJSONFile = "https://pixabay.com/api/?key=24175925-f2016e765d25a20f1cb0a6989&image_type=photo&pretty=true&q=" + search;

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, urlJSONFile, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("hits");
                            for(int i = 0; i < jsonArray.length(); i++){
                                JSONObject hit = jsonArray.getJSONObject(i);
                                String creator = hit.getString("user");
                                int likes = hit.getInt("likes");
                                String imageUrl = hit.getString("webformatURL");
                                itemArrayList.add(new ModelItem(imageUrl, creator, likes));
                            }
                            adapterItem = new AdapterItem(MainActivity.this, itemArrayList);
                            recyclerView.setAdapter(adapterItem);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        requestQueue.add(request);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();

        parseJSON(search);
    }

   public void searchImage(View view){
        itemArrayList.clear();
        search = etSearch.getText().toString().trim();
        parseJSON(search);
   }

}